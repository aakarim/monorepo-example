Functionality related to @go_googleapis
=======================================

color_service_test
------------------

Verifies that a simple gRPC client and server can be built and run. .proto
files are compiled at build time and depend on libraries in ``@go_googleapis``.
