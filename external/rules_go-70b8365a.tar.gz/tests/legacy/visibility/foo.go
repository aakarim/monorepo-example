package foo

const Foo = 1
