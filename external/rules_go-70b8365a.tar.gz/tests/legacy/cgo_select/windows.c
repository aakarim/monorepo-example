const char* goos = "windows";
