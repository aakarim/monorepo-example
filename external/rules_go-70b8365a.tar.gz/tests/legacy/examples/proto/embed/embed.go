package embed

func OtherThing() *EmbedExample {
	return &EmbedExample{
		A: 42,
	}
}
