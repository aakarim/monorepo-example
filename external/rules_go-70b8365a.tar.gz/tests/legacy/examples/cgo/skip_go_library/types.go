package skip_go_library

type Type struct{}
