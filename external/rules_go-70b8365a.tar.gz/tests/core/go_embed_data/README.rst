go_embed_data
=============

.. _go_embed_data: /extras.rst#go-embed-data

Tests to ensure basic features of `go_embed_data`_ are working correctly.

embed_test
----------

Depends on multiple ``go_embed_data`` targets and verifies their contents.
