package platform_lib

const Platform = "windows"
