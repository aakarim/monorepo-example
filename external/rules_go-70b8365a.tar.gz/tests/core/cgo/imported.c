int foo() { return 42; }
