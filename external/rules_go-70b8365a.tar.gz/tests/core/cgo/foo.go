package main

// void foo();
import "C"

func main() {
	C.foo()
}
