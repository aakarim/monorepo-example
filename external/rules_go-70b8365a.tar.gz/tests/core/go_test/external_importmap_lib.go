package external_importmap

type Object interface {
	DeepCopyObject() Object
}
